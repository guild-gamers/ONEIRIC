﻿using System;

[Serializable]
class ConsumableItem
{

}
