﻿using System;

[Serializable]
class WearingItem : EquipableItem
{

}
