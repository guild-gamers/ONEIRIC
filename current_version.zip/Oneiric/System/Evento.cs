﻿class Evento
{
    protected string nombre;
}
