﻿using System;

class Game
{
    protected MainCharacter character;
    protected Room room;
    protected bool finished;
    protected Font font18;
    protected Random rand;
    protected int steps;
    protected int randMax = 350;
    protected int randMin = 50;
    protected byte countTimer;
    protected long time;
    protected GameMenuScreen gm;

    public Game()
    {
        character = new MainCharacter();
        finished = false;
        font18 = new Font("data/fonts/Joystix.ttf", 18);
        room = new Room();
        rand = new Random();
        steps = rand.Next(randMin,randMax);
        time = 0;
        countTimer = 0;
        gm = new GameMenuScreen();
    }

    void UpdateScreen()
    {
        SdlHardware.ClearScreen();
        room.DrawOnHiddenScreen();

        character.DrawOnHiddenScreen();

        SdlHardware.ShowHiddenScreen();
    }

    void CheckInput()
    {
        if (SdlHardware.KeyPressed(SdlHardware.KEY_RIGHT) && character.GetX()
            >= room.MaxRight)
        {
            room.ActualCol++;
            room.UpdateScreenMap(room.ActualCol, room.ActualRow);
            character.MoveTo(0, character.GetY());
            steps--;
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_RIGHT))
        {
            if (room.CanMoveTo(character.GetX() + character.GetSpeedX(),
                    character.GetY(),
                    character.GetX() + character.GetWidth() + 
                    character.GetSpeedX(),
                    character.GetY() + character.GetHeight()))
            {
                character.MoveRight();
                steps--;
            }
            else
            {
                character.NextFrame();
            }
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_LEFT) && 
            character.GetX() <= 0)
        {
            room.ActualCol--;
            room.UpdateScreenMap(room.ActualCol, room.ActualRow);
            character.MoveTo(room.MaxRight, character.GetY());
            steps--;
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_LEFT))
        {
            if (room.CanMoveTo(character.GetX() - character.GetSpeedX(),
                    character.GetY(),
                    character.GetX() + character.GetWidth() - 
                    character.GetSpeedX(),
                    character.GetY() + character.GetHeight()))
            {
                character.MoveLeft();
                steps--;
            }
            else
            {
                character.NextFrame();
            }
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_UP) && 
            character.GetY() <= room.GetTopMargin())
        {
            room.ActualRow--;
            room.UpdateScreenMap(room.ActualCol, room.ActualRow);
            character.MoveTo(character.GetX(), room.MaxDown);
            steps--;
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_UP))
        {
            if (room.CanMoveTo(character.GetX(),
                    character.GetY() - character.GetSpeedY(),
                    character.GetX() + character.GetWidth(),
                    character.GetY() + character.GetHeight() - 
                    character.GetSpeedY()))
            {
                character.MoveUp();
                steps--;
            }
            else
            {
                character.NextFrame();
            }
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_DOWN) && 
            character.GetY() >= room.MaxDown)
        {
            room.ActualRow++;
            room.UpdateScreenMap(room.ActualCol, room.ActualRow);
            character.MoveTo(character.GetX(), room.GetTopMargin());
            steps--;
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_DOWN))
        {
            if (room.CanMoveTo(character.GetX(),
                    character.GetY() + character.GetSpeedY(),
                    character.GetX() + character.GetWidth(),
                    character.GetY() + character.GetHeight() + 
                    character.GetSpeedY()))
            {
                character.MoveDown();
                steps--;
            }
            else
            {
                character.NextFrame();
            }
        }

        if (SdlHardware.KeyPressed(SdlHardware.KEY_I))
        {
            gm.Run(room,character);
        }

        if (SdlHardware.KeyPressed(SdlHardware.KEY_ESC))
            finished = true;
    }

    void CheckFights()
    {
        if (steps == 0)
        {
            //Call Battle
            steps = rand.Next(randMin,randMax);
        }
    }

    void Timer()
    {
        if (countTimer == 25)
        {
            time++;
            countTimer = 0;
        }

        countTimer++;
    }

    void PauseUntilNextFrame()
    {
        SdlHardware.Pause(40); //(40 ms = 25 fps)
    }

    static void UpdateHighscore()
    {
        // Save highest score
        // TO DO
    }

    public void Run()
    {
        do
        {
            UpdateScreen();

            CheckInput();

            CheckFights();

            Timer();

            PauseUntilNextFrame();
        }
        while (!finished);
    }
}