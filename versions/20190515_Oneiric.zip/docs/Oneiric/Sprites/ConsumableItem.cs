﻿class ConsumableItem : Item
{

}
