﻿class NormalEnemy : Enemy
{

}
