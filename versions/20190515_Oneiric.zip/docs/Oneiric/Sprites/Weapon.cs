﻿class Weapons : EquipableItem
{

}
