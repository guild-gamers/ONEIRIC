﻿class EquipableItem : Item
{

}
