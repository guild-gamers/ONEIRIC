﻿using System.Collections.Generic;

class GameMenuScreen : Screen
{
    protected Image selector;
    protected int option;
    protected Font font72;

    const int YCURSOR_MAX = 6;
    const int YCURSOR_MIN = 0;

    public GameMenuScreen()
        : base(new Image("data/images/other/welcome.jpg"),
            new Font("data/fonts/Joystix.ttf", 28))
    {
        option = 0;
        selector = new Image("data/images/other/selector.png");
        font72 = new Font("data/fonts/Joystix.ttf", 72);
        texts = new Dictionary<string, string>();
    }

    public void Run(Room room, MainCharacter character)
    {
        option = 0;
        LoadText(Oneiric.Languages[Oneiric.Language], "gameMenu");

        do
        {
            SdlHardware.ClearScreen();
            room.DrawOnHiddenScreen();
            character.DrawOnHiddenScreen();
            DrawMenu();
            SdlHardware.ShowHiddenScreen();
            if (SdlHardware.KeyPressed(SdlHardware.KEY_UP) && option >
                YCURSOR_MIN)
            {
                option--;
            }
            else if (SdlHardware.KeyPressed(SdlHardware.KEY_DOWN) && option <
                YCURSOR_MAX)
            {
                option++;
            }
            else if (SdlHardware.KeyPressed(SdlHardware.KEY_ESC))
            {
                option = YCURSOR_MAX;
            }
            else if (SdlHardware.KeyPressed(SdlHardware.KEY_RETURN))
            {
                //TO DO
            }
            SdlHardware.Pause(100);
        }
        while (true);
        //The loop ends when an option is choosed.
    }

    public void DrawMenu()
    {
        //SdlHardware.DrawHiddenImage(Wallpaper, 0, 0);
        SdlHardware.WriteHiddenText(texts["mn"],
            942, 142,
            0x00, 0x00, 0x00,
            Font28);
        SdlHardware.WriteHiddenText(texts["mn"],
            940, 140,
            0xFF, 0xFF, 0xFF,
            Font28);
        SdlHardware.WriteHiddenText(texts["eq"],
            922, 222,
            0x00, 0x00, 0x00,
            Font28);
        SdlHardware.WriteHiddenText(texts["eq"],
            920, 220,
            0xFF, 0xFF, 0xFF,
            Font28);
        SdlHardware.WriteHiddenText(texts["in"],
            922, 282,
            0x00, 0x00, 0x00,
            Font28);
        SdlHardware.WriteHiddenText(texts["in"],
            920, 280,
            0xFF, 0xFF, 0xFF,
            Font28);
        SdlHardware.WriteHiddenText(texts["sn"],
            922, 342,
            0x00, 0x00, 0x00,
            Font28);
        SdlHardware.WriteHiddenText(texts["sn"],
            920, 340,
            0xFF, 0xFF, 0xFF,
            Font28);
        SdlHardware.WriteHiddenText(texts["sv"],
            922, 402,
            0x00, 0x00, 0x00,
            Font28);
        SdlHardware.WriteHiddenText(texts["sv"],
            920, 400,
            0xFF, 0xFF, 0xFF,
            Font28);
        SdlHardware.WriteHiddenText(texts["op"],
            922, 462,
            0x00, 0x00, 0x00,
            Font28);
        SdlHardware.WriteHiddenText(texts["op"],
            920, 460,
            0xFF, 0xFF, 0xFF,
            Font28);
        SdlHardware.WriteHiddenText(texts["tt"],
            922, 522,
            0x00, 0x00, 0x00,
            Font28);
        SdlHardware.WriteHiddenText(texts["tt"],
            920, 520,
            0xFF, 0xFF, 0xFF,
            Font28);
        SdlHardware.WriteHiddenText(texts["cl"],
            922, 582,
            0x00, 0x00, 0x00,
            Font28);
        SdlHardware.WriteHiddenText(texts["cl"],
            920, 580,
            0xFF, 0xFF, 0xFF,
            Font28);
        SdlHardware.DrawHiddenImage(selector, 830, 200 + 60 * option);
    }
}
