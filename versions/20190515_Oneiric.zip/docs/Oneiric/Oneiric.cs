﻿class Oneiric
{
    public static byte Language { get; set; }
    public static byte Difficulty { get; set; }
    public static byte MAX_VOLUME = 10;
    public static byte Volume { get; set; }
    public static bool FullScreen { get; set; }
    public static string[] Languages = { "ESPAÑOL", "ENGLISH" };
    public static string[] Difficultation = { "es", "md", "hr" };

    public static void Inicialize()
    {
        FullScreen = false;
        Language = 0;
        Difficulty = 1;
        Volume = 10;
    }

    static void Main()
    {
        Inicialize();

        SdlHardware.Init(1200, 768, 24, FullScreen);
        WelcomeScreen w = new WelcomeScreen();
        OptionsScreen os = new OptionsScreen();
        LoadGamesScreen lg = new LoadGamesScreen();
        Game g;        

        int option;

        do
        {
            option = w.Run();
            switch (option)
            {
                case 0: break;
                case 1: g = new Game();  g.Run();
                    break;
                case 2: lg.Run();
                    break;
                case 3: os.Run();
                    SdlHardware.Init(1200, 768, 24, FullScreen);
                    break;
                case 4: break;
            }
        } while (option != 5);
        
    }
}
