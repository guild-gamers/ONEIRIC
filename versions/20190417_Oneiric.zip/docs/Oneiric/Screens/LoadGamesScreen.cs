﻿class LoadGamesScreen
{

}
