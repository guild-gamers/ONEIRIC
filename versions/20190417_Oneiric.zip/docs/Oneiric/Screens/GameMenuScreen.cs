﻿class GameMenuScreen
{

}
