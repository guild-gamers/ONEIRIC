﻿class EffectSkill : Skill
{

}
