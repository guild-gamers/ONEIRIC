﻿class Sound
{

}
