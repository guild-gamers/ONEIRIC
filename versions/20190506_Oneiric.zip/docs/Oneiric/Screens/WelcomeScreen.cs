﻿class WelcomeScreen
{
    protected Image welcome;
    protected Image selector;
    protected int option;
    protected Font font28;

    const int YCURSOR_MAX = 5;
    const int YCURSOR_MIN = 0;

    public WelcomeScreen()
    {
        welcome = new Image("data/images/other/welcome.jpg");
        option = 0;
        font28 = new Font("data/fonts/Joystix.ttf", 28);
        selector = new Image("data/images/other/selector.png");
    }

    public int GetChosenOption()
    {
        return option;
    }

    public int Run()
    {
        option = 0;

        do
        {
            SdlHardware.ClearScreen();
            DrawMenu();
            SdlHardware.ShowHiddenScreen();
            if (SdlHardware.KeyPressed(SdlHardware.KEY_UP) && option > YCURSOR_MIN)
            {
                option--;
            }
            else if (SdlHardware.KeyPressed(SdlHardware.KEY_DOWN) && option < YCURSOR_MAX)
            {
                option++;
            }
            else if (SdlHardware.KeyPressed(SdlHardware.KEY_RETURN))
            {
                return option;
            }
            SdlHardware.Pause(100);
        }
        while (true);
    }

    public void DrawMenu()
    {
        SdlHardware.DrawHiddenImage(welcome, 0, 0);
        SdlHardware.WriteHiddenText("Continuar",
           422, 402,
           0x00, 0x00, 0x00,
           font28);
        SdlHardware.WriteHiddenText("Continuar",
            420, 400,
            0xFF, 0xFF, 0xFF,
            font28);

        SdlHardware.WriteHiddenText("Nueva Partida",
            422, 442,
            0x00, 0x00, 0x00,
            font28);
        SdlHardware.WriteHiddenText("Nueva Partida",
            420, 440,
            0xFF, 0xFF, 0xFF,
            font28);
        SdlHardware.WriteHiddenText("Cargar Partida",
            422, 482,
            0x00, 0x00, 0x00,
            font28);
        SdlHardware.WriteHiddenText("Cargar Partida",
            420, 480,
            0xFF, 0xFF, 0xFF,
            font28);
        SdlHardware.WriteHiddenText("Opciones",
            422, 522,
            0x00, 0x00, 0x00,
            font28);
        SdlHardware.WriteHiddenText("Opciones",
            420, 520,
            0xFF, 0xFF, 0xFF,
            font28);
        SdlHardware.WriteHiddenText("Ayuda",
            422, 562,
            0x00, 0x00, 0x00,
            font28);
        SdlHardware.WriteHiddenText("Ayuda",
            420, 560,
            0xFF, 0xFF, 0xFF,
            font28);
        SdlHardware.WriteHiddenText("Salir",
            422, 602,
            0x00, 0x00, 0x00,
            font28);
        SdlHardware.WriteHiddenText("Salir",
            420, 600,
            0xFF, 0xFF, 0xFF,
            font28);
        SdlHardware.DrawHiddenImage(selector, 360, 400 + 40 * option);
    }
}