﻿class OptionsScreen
{
    protected Image welcome;
    protected Image selector;
    protected int option;
    protected Font font28;

    const int YCURSOR_MAX = 4;
    const int YCURSOR_MIN = 0;

    public OptionsScreen()
    {
        welcome = new Image("data/images/other/welcome.jpg");
        option = 0;
        font28 = new Font("data/fonts/Joystix.ttf", 28);
        selector = new Image("data/images/other/selector.png");
    }

    public int GetChosenOption()
    {
        return option;
    }

    public int Run(string[] languages, ref byte language,
        string[] diffifultation, ref byte difficulty,
        ref bool fullScreen)
    {
        option = 0;
        SdlHardware.Pause(100);
        do
        {
            SdlHardware.ClearScreen();
            DrawMenu(languages[language], diffifultation[difficulty], fullScreen);
            SdlHardware.ShowHiddenScreen();
            if (SdlHardware.KeyPressed(SdlHardware.KEY_UP) && option > YCURSOR_MIN)
            {
                option--;
            }
            else if (SdlHardware.KeyPressed(SdlHardware.KEY_DOWN) && option < YCURSOR_MAX)
            {
                option++;
            }
            else if (SdlHardware.KeyPressed(SdlHardware.KEY_RETURN))
            {
                return option;
            }
            else if(SdlHardware.KeyPressed(SdlHardware.KEY_LEFT))
            {
                ChangeOptions(-1, 
                    ref language, languages.Length-1, 
                    ref difficulty, diffifultation.Length-1,
                    ref fullScreen);
            }
            else if (SdlHardware.KeyPressed(SdlHardware.KEY_RIGHT))
            {
                ChangeOptions(1, 
                    ref language, languages.Length - 1, 
                    ref difficulty, diffifultation.Length - 1,
                    ref fullScreen);
            }
            SdlHardware.Pause(100);
        }
        while (true);
    }

    public void ChangeOptions(sbyte num, 
        ref byte language,int totalLanguages, 
        ref byte difficulty, int totalDiddiculty,
        ref bool fullScreen)
    {
        switch (option)
        {
            case 0:
                if ((language + num) >= 0 && (language + num) <= totalLanguages)
                {
                    language += (byte)num;
                }
                break;
            case 1:
                if ((difficulty + num) >= 0 && (difficulty + num) <= totalDiddiculty)
                {
                    difficulty += (byte)num;
                }
                break;
            case 2:
                fullScreen = fullScreen ? false : true;
                break;
        }
    }

    public void DrawMenu(string lang, string difficulty, bool fullcreen)
    {
        SdlHardware.DrawHiddenImage(welcome, 0, 0);
        SdlHardware.WriteHiddenText("Idioma: < " + lang + " >",
           422, 402,
           0x00, 0x00, 0x00,
           font28);
        SdlHardware.WriteHiddenText("Idioma: < " + lang + " >",
            420, 400,
            0xFF, 0xFF, 0xFF,
            font28);

        SdlHardware.WriteHiddenText("Dificultad: < " + difficulty + " >",
            422, 442,
            0x00, 0x00, 0x00,
            font28);
        SdlHardware.WriteHiddenText("Dificultad: < " + difficulty + " >",
            420, 440,
            0xFF, 0xFF, 0xFF,
            font28);
        SdlHardware.WriteHiddenText("Pantalla Completa: < " + (fullcreen? "Sí":"No") + " >",
            422, 482,
            0x00, 0x00, 0x00,
            font28);
        SdlHardware.WriteHiddenText("Pantalla Completa: < " + (fullcreen ? "Sí" : "No") + " >",
            420, 480,
            0xFF, 0xFF, 0xFF,
            font28);
        SdlHardware.WriteHiddenText("Volumen",
            422, 522,
            0x00, 0x00, 0x00,
            font28);
        SdlHardware.WriteHiddenText("Volumen",
            420, 520,
            0xFF, 0xFF, 0xFF,
            font28);
        SdlHardware.WriteHiddenText("Atras",
            422, 562,
            0x00, 0x00, 0x00,
            font28);
        SdlHardware.WriteHiddenText("Atras",
            420, 560,
            0xFF, 0xFF, 0xFF,
            font28);
        SdlHardware.DrawHiddenImage(selector, 360, 400 + 40 * option);
    }
}
