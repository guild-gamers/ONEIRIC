﻿class BattleScreen
{

}
