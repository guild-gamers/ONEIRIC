﻿class MainCharacter : Character
{

}
