﻿abstract class Character : Sprite
{

}
