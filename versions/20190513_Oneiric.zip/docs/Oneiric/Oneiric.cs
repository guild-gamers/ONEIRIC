﻿class Oneiric
{
    static void Main()
    {
        bool fullScreen = false;
        SdlHardware.Init(1200, 768, 24, fullScreen);

        WelcomeScreen w = new WelcomeScreen();
        OptionsScreen os = new OptionsScreen();
        Game g = new Game();

        string[] languages = {"ESPAÑOL","ENGLISH"};
        string[] diffifultation = {"Fácil","Medio","Díficil"};

        byte language = 0;
        byte difficulty = 1;

        int option;

        do
        {
            option = w.Run();
            switch (option)
            {
                case 0: break;
                case 1: g.Run();
                    break;
                case 2: break;
                case 3: os.Run(languages,ref language,
                                diffifultation, ref difficulty,
                                ref fullScreen);
                    SdlHardware.Init(1200, 768, 24, fullScreen);
                    break;
                case 4: break;
            }
        } while (option != 5);
        
    }
}
