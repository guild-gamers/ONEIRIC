﻿class Game
{
    protected MainCharacter character;
    protected Room room;
    protected bool finished;
    protected Font font18;

    public Game()
    {
        character = new MainCharacter();

        finished = false;

        font18 = new Font("data/fonts/Joystix.ttf", 18);
        room = new Room();
    }

    void UpdateScreen()
    {
        SdlHardware.ClearScreen();
        room.DrawOnHiddenScreen();

        character.DrawOnHiddenScreen();

        SdlHardware.ShowHiddenScreen();
    }

    void CheckInput()
    {
        if (SdlHardware.KeyPressed(SdlHardware.KEY_RIGHT) && character.GetX()
            >= room.MaxRight)
        {
            room.ActualCol++;
            room.UpdateScreenMap(room.ActualCol, room.ActualRow);
            character.MoveTo(0, character.GetY());
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_RIGHT))
        {
            if (room.CanMoveTo(character.GetX() + character.GetSpeedX(),
                    character.GetY(),
                    character.GetX() + character.GetWidth() + 
                    character.GetSpeedX(),
                    character.GetY() + character.GetHeight()))
            {
                character.MoveRight();
            }
            else
            {
                character.NextFrame();
            }
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_LEFT) && 
            character.GetX() <= 0)
        {
            room.ActualCol--;
            room.UpdateScreenMap(room.ActualCol, room.ActualRow);
            character.MoveTo(room.MaxRight, character.GetY());
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_LEFT))
        {
            if (room.CanMoveTo(character.GetX() - character.GetSpeedX(),
                    character.GetY(),
                    character.GetX() + character.GetWidth() - 
                    character.GetSpeedX(),
                    character.GetY() + character.GetHeight()))
            {
                character.MoveLeft();
            }
            else
            {
                character.NextFrame();
            }
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_UP) && 
            character.GetY() <= room.GetTopMargin())
        {
            room.ActualRow--;
            room.UpdateScreenMap(room.ActualCol, room.ActualRow);
            character.MoveTo(character.GetX(), room.MaxDown);
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_UP))
        {
            if (room.CanMoveTo(character.GetX(),
                    character.GetY() - character.GetSpeedY(),
                    character.GetX() + character.GetWidth(),
                    character.GetY() + character.GetHeight() - 
                    character.GetSpeedY()))
            {
                character.MoveUp();
            }
            else
            {
                character.NextFrame();
            }
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_DOWN) && 
            character.GetY() >= room.MaxDown)
        {
            room.ActualRow++;
            room.UpdateScreenMap(room.ActualCol, room.ActualRow);
            character.MoveTo(character.GetX(), room.GetTopMargin());
        }
        else if (SdlHardware.KeyPressed(SdlHardware.KEY_DOWN))
        {
            if (room.CanMoveTo(character.GetX(),
                    character.GetY() + character.GetSpeedY(),
                    character.GetX() + character.GetWidth(),
                    character.GetY() + character.GetHeight() + 
                    character.GetSpeedY()))
            {
                character.MoveDown();
            }
            else
            {
                character.NextFrame();
            }
        }

        if (SdlHardware.KeyPressed(SdlHardware.KEY_ESC))
            finished = true;
    }


    void PauseUntilNextFrame()
    {
        SdlHardware.Pause(40); //(40 ms = 25 fps)
    }

    static void UpdateHighscore()
    {
        // Save highest score
        // TO DO
    }

    public void Run()
    {
        do
        {
            UpdateScreen();

            CheckInput();

            PauseUntilNextFrame();
        }
        while (!finished);
    }
}