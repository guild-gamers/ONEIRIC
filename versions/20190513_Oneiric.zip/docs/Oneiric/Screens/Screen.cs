﻿abstract class Screen
{
    public Image Wallpaper { get; set; }
    public Font Font28 { get; set; }

    public Screen(Image wallpaper, Font font28)
    {
        Wallpaper = wallpaper;
        Font28 = font28;
    }
}
