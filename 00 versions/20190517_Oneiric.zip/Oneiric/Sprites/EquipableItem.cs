﻿class EquipableItem
{
}
