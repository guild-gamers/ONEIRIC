﻿using System;

abstract class InteractibleElement
{
}
