﻿class PassiveSkill : Skill
{
    
}
