﻿class Skill
{

}
