﻿class Bosses : Enemy
{

}
