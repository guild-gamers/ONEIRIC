﻿using System;

abstract class Character : Sprite
{

}
