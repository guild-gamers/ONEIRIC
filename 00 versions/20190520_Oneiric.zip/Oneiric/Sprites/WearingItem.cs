﻿class WearingItem : EquipableItem
{

}
