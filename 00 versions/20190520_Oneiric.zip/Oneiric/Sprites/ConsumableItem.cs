﻿class ConsumableItem
{

}
