﻿class Npc
{

}
