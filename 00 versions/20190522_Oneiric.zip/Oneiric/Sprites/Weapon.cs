﻿class Weapon : EquipableItem
{

}
