﻿abstract class Enemy : Character
{
}
