﻿using System;

[Serializable]
class EquipableItem
{
}
