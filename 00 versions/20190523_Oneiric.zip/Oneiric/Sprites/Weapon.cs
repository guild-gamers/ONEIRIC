﻿using System;

[Serializable]
class Weapon : EquipableItem
{

}
