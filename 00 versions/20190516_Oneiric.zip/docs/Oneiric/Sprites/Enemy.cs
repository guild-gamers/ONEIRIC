﻿abstract class Enemy : Character
{

}
