﻿using System;

[Serializable]
abstract class Character : Sprite
{

}
